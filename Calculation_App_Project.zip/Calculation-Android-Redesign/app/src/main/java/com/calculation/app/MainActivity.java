package com.calculation.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root, keys;
    private TextView expressionView, resultView;
    private String expression = "";
    private boolean scientific = false, light = false, degrees = true, inverse = false, resultFresh = false;
    private final List<String> history = new ArrayList<>();
    private int bg, keyTop, keyBottom, text, muted, orange, operatorTop, operatorBottom;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        loadHistory();
        render();
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        render();
    }

    private int c(String hex) { return Color.parseColor(hex); }
    private void palette() {
        if (light) {
            bg=c("#F3F4FA"); keyTop=c("#57595F"); keyBottom=c("#292B30"); text=c("#20212A"); muted=c("#7D8090"); orange=c("#FF982F"); operatorTop=c("#5551A8"); operatorBottom=c("#34316F");
            getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        } else {
            bg=c("#171719"); keyTop=c("#414247"); keyBottom=c("#222327"); text=c("#F7F7F9"); muted=c("#A5A6AD"); orange=c("#FF982F"); operatorTop=c("#414247"); operatorBottom=c("#222327");
            getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); getWindow().getDecorView().setSystemUiVisibility(0);
        }
    }

    private void render() {
        palette();
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg); root.setPadding(dp(12),dp(5),dp(12),dp(8)); setContentView(root);
        LinearLayout toolbar = new LinearLayout(this); toolbar.setGravity(Gravity.CENTER_VERTICAL); toolbar.setOrientation(LinearLayout.HORIZONTAL); root.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(52)));
        Button floatButton = toolButton("↙↗"); floatButton.setOnClickListener(v -> enterFloatingMode()); toolbar.addView(floatButton,weight(1));
        Button scientificButton = toolButton(scientific ? "123" : "√  π\ne ="); scientificButton.setOnClickListener(v->{scientific=!scientific;render();}); toolbar.addView(scientificButton,weight(1));
        Button historyButton = toolButton("▦"); historyButton.setOnClickListener(v->showHistory()); toolbar.addView(historyButton,weight(1));
        Button moreButton = toolButton("⋮"); moreButton.setOnClickListener(v->showMenu(moreButton)); toolbar.addView(moreButton,weight(1));

        LinearLayout display = new LinearLayout(this); display.setOrientation(LinearLayout.VERTICAL); display.setGravity(Gravity.BOTTOM|Gravity.END); display.setPadding(dp(8),dp(12),dp(8),dp(18));
        LinearLayout.LayoutParams displayLp = new LinearLayout.LayoutParams(-1,0,1.0f); displayLp.setMargins(dp(4),dp(2),dp(4),dp(10)); root.addView(display,displayLp);
        TextView mode = label(scientific ? (degrees?"SCIENTIFIC  ·  DEG":"SCIENTIFIC  ·  RAD") : "",13,muted,true); mode.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); display.addView(mode,new LinearLayout.LayoutParams(-1,dp(28)));
        expressionView=label(expression,24,muted,false); expressionView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); expressionView.setSingleLine(true); expressionView.setHorizontallyScrolling(true); display.addView(expressionView,new LinearLayout.LayoutParams(-1,dp(46)));
        resultView=label(resultFresh?expression:"0",42,text,false); resultView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); resultView.setSingleLine(true); resultView.setHorizontallyScrolling(true); display.addView(resultView,new LinearLayout.LayoutParams(-1,dp(60)));

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1.45f));
        keys = new LinearLayout(this); keys.setOrientation(LinearLayout.VERTICAL); scroll.addView(keys,new ScrollView.LayoutParams(-1,-1));
        if (scientific) {
            addRow(new String[]{inverse?"asin":"sin",inverse?"acos":"cos",inverse?"atan":"tan",degrees?"DEG":"RAD","inv"},true);
            addRow(new String[]{"log","ln","(",")","!"},true);
            addRow(new String[]{"^","√","π","e","%"},true);
            addRow(new String[]{"AC","DEL","7","8","9"},false);
            addRow(new String[]{"÷","4","5","6","×"},false);
            addRow(new String[]{"−","1","2","3","+"},false);
            addRow(new String[]{"00","0",".","⌫","="},false);
        } else {
            addRow(new String[]{"AC","%","⌫","÷"},false);
            addRow(new String[]{"7","8","9","×"},false);
            addRow(new String[]{"4","5","6","−"},false);
            addRow(new String[]{"1","2","3","+"},false);
            addRow(new String[]{"00","0",".","="},false);
        }
        TextView footer=label("CALCULATION  ·  WORKS OFFLINE",10,muted,true); footer.setGravity(Gravity.CENTER); footer.setLetterSpacing(.10f); footer.setPadding(0,dp(7),0,0); root.addView(footer,new LinearLayout.LayoutParams(-1,dp(22)));
    }

    private LinearLayout.LayoutParams weight(float w) { return new LinearLayout.LayoutParams(0,dp(48),w); }
    private void addRow(String[] labels, boolean small) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER); LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,0,1); rlp.setMargins(0,dp(2),0,dp(2)); keys.addView(row,rlp);
        for(String s:labels){
            Button b=new Button(this); b.setAllCaps(false); b.setText(s); b.setTextSize(s.length()>3?15:(small?18:24)); b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); b.setTextColor(buttonText(s)); b.setBackground(gloss(buttonTop(s),buttonBottom(s),s.equals("="))); b.setStateListAnimator(null); b.setPadding(0,0,0,0); b.setMinWidth(0); b.setMinHeight(0); b.setIncludeFontPadding(false); b.setElevation(dp(2));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1); lp.setMargins(dp(4),dp(4),dp(4),dp(4)); row.addView(b,lp); b.setOnClickListener(v->tap(s));
        }
    }
    private int buttonTop(String s){if(s.equals("="))return orange;if(isOperator(s)||s.equals("AC")||s.equals("inv")||s.equals("RAD")||s.equals("DEG"))return operatorTop;return keyTop;}
    private int buttonBottom(String s){if(s.equals("="))return c("#F58219");if(isOperator(s)||s.equals("AC")||s.equals("inv")||s.equals("RAD")||s.equals("DEG"))return operatorBottom;return keyBottom;}
    private int buttonText(String s){if(s.equals("="))return Color.WHITE;if(s.equals("AC"))return c("#FFB46B");if(isOperator(s)||s.equals("inv")||s.equals("RAD")||s.equals("DEG")||s.equals("sin")||s.equals("cos")||s.equals("tan")||s.equals("asin")||s.equals("acos")||s.equals("atan")||s.equals("log")||s.equals("ln")||s.equals("√")||s.equals("π")||s.equals("e")||s.equals("!"))return light?c("#FFFFFF"):c("#D7D7DB");return text;}
    private boolean isOperator(String s){return s.equals("÷")||s.equals("×")||s.equals("−")||s.equals("+")||s.equals("%")||s.equals("^")||s.equals("(")||s.equals(")");}
    private GradientDrawable gloss(int top,int bottom,boolean isEquals){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{top,bottom});d.setCornerRadius(dp(isEquals?40:44));d.setStroke(dp(1),Color.argb(light?55:70,255,255,255));return d;}

    private Button toolButton(String s){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextSize(s.contains("\n")?15:23);b.setTextColor(text);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);b.setMinWidth(0);b.setMinHeight(0);return b;}
    private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));return t;}
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}

    private void tap(String s){
        if(s.equals("AC")){expression="";resultFresh=false;refreshDisplay();return;}
        if(s.equals("DEL")||s.equals("⌫")){if(!expression.isEmpty())expression=expression.substring(0,expression.length()-1);resultFresh=false;refreshDisplay();return;}
        if(s.equals("=")){evaluate();return;}
        if(s.equals("inv")){inverse=!inverse;render();return;}
        if(s.equals("RAD")||s.equals("DEG")){degrees=!degrees;render();return;}
        if(resultFresh && (isDigit(s)||s.equals(".")||s.equals("00")))expression="";
        resultFresh=false;
        switch(s){
            case "sin":case "cos":case "tan":case "asin":case "acos":case "atan":case "log":case "ln":expression+=s+"(";break;
            case "√":expression+="sqrt(";break;
            case "π":expression+="pi";break;
            case "e":expression+="e";break;
            case "00":expression+="00";break;
            case "×":expression+="*";break;
            case "÷":expression+="/";break;
            case "−":expression+="-";break;
            default:expression+=s;
        }
        refreshDisplay();
    }
    private boolean isDigit(String s){return s.length()==1&&s.charAt(0)>='0'&&s.charAt(0)<='9';}
    private void refreshDisplay(){if(expressionView!=null){expressionView.setText(expression);resultView.setText(resultFresh?expression:"0");}}
    private void evaluate(){if(expression.trim().isEmpty())return;try{double value=new Parser(expression,degrees).parse();if(!Double.isFinite(value))throw new Exception("Math error");String ans=format(value);String item=expression+" = "+ans;history.add(0,item);while(history.size()>100)history.remove(history.size()-1);saveHistory();expression=ans;resultFresh=true;expressionView.setText(item.substring(0,item.lastIndexOf(" = ")));resultView.setText(ans);}catch(Exception e){resultView.setText("Error");Toast.makeText(this,"Expression check karo",Toast.LENGTH_SHORT).show();}}
    private String format(double v){if(Math.abs(v)<1e-12)v=0;if(Math.abs(v)<1e12&&v==Math.rint(v))return String.format(Locale.US,"%.0f",v);return BigDecimal.valueOf(v).setScale(10,RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();}

    private void showHistory(){if(history.isEmpty()){new AlertDialog.Builder(this).setTitle("History").setMessage("Abhi koi calculation saved nahi hai.").setPositiveButton("OK",null).show();return;}String[] items=history.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("Calculation history").setItems(items,(d,w)->{String item=items[w];int ix=item.lastIndexOf(" = ");expression=ix>=0?item.substring(ix+3):item;resultFresh=true;render();}).setNeutralButton("Clear history",(d,w)->{history.clear();saveHistory();Toast.makeText(this,"History cleared",Toast.LENGTH_SHORT).show();}).setNegativeButton("Close",null).show();}
    private void showMenu(View anchor){PopupMenu menu=new PopupMenu(this,anchor);menu.getMenu().add("Switch to "+(light?"Dark":"Light")+" theme");menu.getMenu().add(scientific?"Basic calculator":"Scientific calculator");menu.getMenu().add(degrees?"Use radians":"Use degrees");menu.getMenu().add("Calculation history");menu.getMenu().add("Clear history");menu.getMenu().add("About Calculation");menu.setOnMenuItemClickListener(item->{String t=item.getTitle().toString();if(t.contains("theme")){light=!light;render();}else if(t.contains("calculator")){scientific=!scientific;render();}else if(t.contains("radians")||t.contains("degrees")){degrees=!degrees;render();}else if(t.equals("Calculation history")){showHistory();}else if(t.equals("Clear history")){history.clear();saveHistory();Toast.makeText(this,"History cleared",Toast.LENGTH_SHORT).show();}else{new AlertDialog.Builder(this).setTitle("Calculation").setMessage("Premium-style offline calculator\nBasic and scientific functions\nVersion 1.1").setPositiveButton("OK",null).show();}return true;});menu.show();}
    private void enterFloatingMode(){if(Build.VERSION.SDK_INT>=26){try{PictureInPictureParams params=new PictureInPictureParams.Builder().setAspectRatio(new Rational(3,4)).build();enterPictureInPictureMode(params);}catch(Exception e){Toast.makeText(this,"Floating mode is not supported on this device",Toast.LENGTH_SHORT).show();}}else Toast.makeText(this,"Floating mode requires Android 8 or newer",Toast.LENGTH_SHORT).show();}
    private void saveHistory(){getSharedPreferences("calculation",MODE_PRIVATE).edit().putString("history",android.text.TextUtils.join("\n",history)).apply();}
    private void loadHistory(){String saved=getSharedPreferences("calculation",MODE_PRIVATE).getString("history","");if(!saved.isEmpty()){String[] a=saved.split("\n");for(String x:a)if(!x.trim().isEmpty())history.add(x);}}

    private static class Parser {
        private final String s;private final boolean degrees;private int p=0;
        Parser(String input,boolean degrees){s=input.replace("×","*").replace("÷","/").replace("−","-");this.degrees=degrees;}
        double parse()throws Exception{double v=expression();skip();if(p<s.length())throw new Exception("Unexpected token");return v;}
        double expression()throws Exception{double v=term();while(true){skip();if(eat('+'))v+=term();else if(eat('-'))v-=term();else return v;}}
        double term()throws Exception{double v=unary();while(true){skip();if(eat('*'))v*=unary();else if(eat('/')){double d=unary();if(d==0)throw new Exception("Divide by zero");v/=d;}else return v;}}
        double unary()throws Exception{skip();if(eat('+'))return unary();if(eat('-'))return -unary();double v=power();while(true){skip();if(eat('%'))v/=100;else if(eat('!')){if(v<0||v>170||v!=Math.rint(v))throw new Exception("Factorial domain");double f=1;for(int i=2;i<=(int)v;i++)f*=i;v=f;}else return v;}}
        double power()throws Exception{double v=primary();skip();if(eat('^'))v=Math.pow(v,unary());return v;}
        double primary()throws Exception{skip();if(eat('(')){double v=expression();skip();if(!eat(')'))throw new Exception("Missing )");return v;}if(p>=s.length())throw new Exception("Expected value");if(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'){int st=p;while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++;return Double.parseDouble(s.substring(st,p));}if(Character.isLetter(s.charAt(p))){int st=p;while(p<s.length()&&Character.isLetter(s.charAt(p)))p++;String n=s.substring(st,p).toLowerCase(Locale.US);if(n.equals("pi"))return Math.PI;if(n.equals("e"))return Math.E;skip();if(!eat('('))throw new Exception("Expected (");double x=expression();skip();if(!eat(')'))throw new Exception("Missing )");switch(n){case "sin":return Math.sin(angle(x));case "cos":return Math.cos(angle(x));case "tan":return Math.tan(angle(x));case "asin":return outAngle(Math.asin(x));case "acos":return outAngle(Math.acos(x));case "atan":return outAngle(Math.atan(x));case "log":if(x<=0)throw new Exception("Domain");return Math.log10(x);case "ln":if(x<=0)throw new Exception("Domain");return Math.log(x);case "sqrt":if(x<0)throw new Exception("Domain");return Math.sqrt(x);default:throw new Exception("Unknown function");}}throw new Exception("Unexpected character");}
        double angle(double x){return degrees?Math.toRadians(x):x;}double outAngle(double x){return degrees?Math.toDegrees(x):x;}void skip(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}boolean eat(char c){if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false;}
    }
}
