# Calculation Android App

Yeh native Android calculator project hai. Website nahi hai.

## Features
- Glossy dark calculator buttons, screenshot-inspired layout
- Basic calculator: +, −, ×, ÷, percentage, decimal, backspace, clear
- Scientific mode: sin/cos/tan, inverse trig, log, ln, factorial, square root, powers, pi, e, brackets
- DEG/RAD switch
- Light/dark theme option
- Saved calculation history (app band karne ke baad bhi)
- Android Picture-in-Picture floating mode button (Android 8+; device support ke hisaab se)
- Offline use, internet permission nahi hai

## GitHub Actions se APK banana, phone par
1. ZIP extract karne ke bajay pehle ZIP ko download karo.
2. GitHub par apni repository kholo.
3. ZIP ko phone par extract karo. Project ke andar ki files aur `.github` folder repository ke root mein upload karo. ZIP file ko akela upload mat karna.
4. Commit/push karne ke baad repository ke **Actions** tab kholo.
5. **Build Calculation APK** workflow select karo. Agar automatic run na ho, **Run workflow** dabao.
6. Green successful build ke baad run ke neeche **Calculation-debug-apk** artifact download karo.
7. Artifact ZIP ko extract karo. `app-debug.apk` install karo. Android prompt aaye to is source se install permission allow karo.

## Build requirements
- JDK 17
- Gradle 8.9
- Android SDK Platform 35 (GitHub-hosted build environment par setup action/tooling ke through)

Note: Is environment mein Android SDK/Gradle compiler available nahi tha, isliye APK ko yahan compile aur test nahi kiya gaya. GitHub Actions workflow project se APK banane ke liye diya hai.
