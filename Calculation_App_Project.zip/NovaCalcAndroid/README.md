# Calculation Android Calculator

A native Android calculator project built with Java and the Android SDK. It is an Android app, not a website, and it works offline.

## Features
- Basic arithmetic, brackets, decimals, percentages and sign toggle
- Scientific mode: sin, cos, tan, log, ln, square root, square, pi, e and factorial
- DEG/RAD angle mode
- Recent calculation history
- Modern dark theme and light theme
- Portrait layout, no third-party libraries, no network permissions

## Build an APK with Android Studio
1. Install Android Studio on a computer from https://developer.android.com/studio
2. Open Android Studio and choose **Open**.
3. Select the extracted `CalculationAndroid` folder (the folder containing `settings.gradle`).
4. Allow Gradle sync. If asked, install Android SDK Platform 35 and a compatible Android Gradle Plugin/Gradle version.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the build finishes, select **locate** in the notification. The APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your Android phone, open it, and allow installation from that source if Android asks.

## Notes
- The project uses Android Gradle Plugin 8.6.1, compile SDK 35 and Java source compatible with standard Android Studio setup.
- This environment did not have the Android SDK or Gradle installed, so an APK could not be compiled and tested here. The source project is provided for building in Android Studio.
