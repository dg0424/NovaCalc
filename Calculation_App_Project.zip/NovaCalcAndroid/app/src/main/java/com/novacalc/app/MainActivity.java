package com.novacalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root, keypad, header;
    private TextView expressionView, resultView, modeView;
    private String expression = "";
    private boolean scientific = false, light = true, degrees = true, resultFresh = false;
    private final List<String> history = new ArrayList<>();
    private int bg, panel, key, text, muted, accent, operatorColor;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(247,247,255));
        getWindow().setNavigationBarColor(Color.rgb(247,247,255));
        render();
    }

    private void setPalette() {
        if (light) {
            bg=Color.rgb(248,248,255); panel=Color.WHITE; key=Color.rgb(241,242,250); text=Color.rgb(27,34,55); muted=Color.rgb(124,132,155); accent=Color.rgb(35,112,245); operatorColor=Color.rgb(235,232,255);
            getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        } else {
            bg=Color.rgb(18,22,34); panel=Color.rgb(29,35,51); key=Color.rgb(40,47,65); text=Color.rgb(245,247,255); muted=Color.rgb(160,169,192); accent=Color.rgb(57,130,255); operatorColor=Color.rgb(48,55,82);
            getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); getWindow().getDecorView().setSystemUiVisibility(0);
        }
    }

    private void render() {
        setPalette();
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(12),dp(18),dp(12)); root.setBackgroundColor(bg);
        setContentView(root);
        header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout brandGroup = new LinearLayout(this); brandGroup.setOrientation(LinearLayout.HORIZONTAL); brandGroup.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = label("∑", 25, Color.WHITE, true); logo.setGravity(Gravity.CENTER); logo.setBackground(round(accent, 15));
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(42),dp(42)); logoLp.setMargins(0,0,dp(10),0); brandGroup.addView(logo,logoLp);
        LinearLayout brandText = new LinearLayout(this); brandText.setOrientation(LinearLayout.VERTICAL); brandText.setGravity(Gravity.CENTER_VERTICAL);
        brandText.addView(label("Calculation", 21, text, true));
        TextView tagline = label("SMART • SIMPLE • PRECISE", 9, muted, true); tagline.setLetterSpacing(.08f); brandText.addView(tagline);
        brandGroup.addView(brandText); header.addView(brandGroup, new LinearLayout.LayoutParams(0,dp(52),1));
        Button historyButton = smallButton("◷", panel, text); historyButton.setOnClickListener(v -> showHistory()); header.addView(historyButton);
        View gap = new View(this); header.addView(gap,new LinearLayout.LayoutParams(dp(8),1));
        Button themeButton = smallButton(light ? "☾" : "☼", panel, text); themeButton.setOnClickListener(v->{light=!light;render();}); header.addView(themeButton);
        root.addView(header);

        LinearLayout display = new LinearLayout(this); display.setOrientation(LinearLayout.VERTICAL); display.setGravity(Gravity.BOTTOM|Gravity.END); display.setPadding(dp(18),dp(18),dp(18),dp(18)); display.setBackground(round(panel,24));
        LinearLayout.LayoutParams displayLp = new LinearLayout.LayoutParams(-1,0,1.1f); displayLp.setMargins(0,dp(14),0,dp(14)); root.addView(display,displayLp);
        modeView = label(scientific ? "SCIENTIFIC MODE" : "STANDARD MODE", 11, accent, true); modeView.setLetterSpacing(.12f); display.addView(modeView);
        expressionView = label(expression.isEmpty()?"Enter a calculation":expression, 18, muted, false); expressionView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); expressionView.setSingleLine(true); expressionView.setPadding(0,dp(14),0,dp(8)); display.addView(expressionView,new LinearLayout.LayoutParams(-1,dp(44)));
        resultView = label("0", 40, text, true); resultView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); resultView.setSingleLine(true); resultView.setTextSize(40); display.addView(resultView,new LinearLayout.LayoutParams(-1,dp(62)));

        LinearLayout modeRow = new LinearLayout(this); modeRow.setOrientation(LinearLayout.HORIZONTAL); modeRow.setGravity(Gravity.CENTER_VERTICAL); modeRow.setPadding(0,0,0,dp(10));
        Button modeButton = smallButton(scientific ? "Basic mode" : "Scientific mode", panel, accent); modeButton.setOnClickListener(v->{scientific=!scientific;render();}); modeRow.addView(modeButton,new LinearLayout.LayoutParams(0,dp(42),1));
        View spacer = new View(this); modeRow.addView(spacer,new LinearLayout.LayoutParams(dp(8),1));
        Button angleButton = smallButton(degrees ? "DEG" : "RAD", panel, text); angleButton.setOnClickListener(v->{degrees=!degrees;angleButton.setText(degrees?"DEG":"RAD");}); modeRow.addView(angleButton,new LinearLayout.LayoutParams(dp(70),dp(42)));
        root.addView(modeRow);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,2.4f));
        keypad = new LinearLayout(this); keypad.setOrientation(LinearLayout.VERTICAL); scroll.addView(keypad);
        if (scientific) {
            addRow(new String[]{"sin","cos","tan","log","ln"});
            addRow(new String[]{"√","x²","π","e","!"});
        }
        addRow(new String[]{"AC","DEL","(",")","÷"});
        addRow(new String[]{"7","8","9","%","×"});
        addRow(new String[]{"4","5","6","−","+"});
        addRow(new String[]{"1","2","3",".","="});
        addRow(new String[]{"0","00","+/−","⌫","="});
        TextView foot = label("CALCULATION  •  WORKS OFFLINE", 11, muted, false); foot.setGravity(Gravity.CENTER); foot.setPadding(0,dp(10),0,0); root.addView(foot);
        updateDisplay();
    }

    private void addRow(String[] labels) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1,0,1); rowLp.setMargins(0,dp(3),0,dp(3)); keypad.addView(row,rowLp);
        for (String s: labels) {
            Button b = new Button(this); b.setAllCaps(false); b.setText(s); b.setTextSize(s.length()>2?14:19); b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); b.setTextColor(buttonText(s)); b.setBackground(round(buttonColor(s),18)); b.setStateListAnimator(null); b.setPadding(0,0,0,0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,-1,1); lp.setMargins(dp(3),dp(3),dp(3),dp(3)); row.addView(b,lp); b.setOnClickListener(v->tap(s));
        }
    }
    private int buttonColor(String s) {
        if(s.equals("=")) return accent;
        if(s.equals("AC")) return light?Color.rgb(255,226,229):Color.rgb(79,43,57);
        if("÷×−+%()".contains(s) && s.length()==1) return operatorColor;
        if(s.equals("sin")||s.equals("cos")||s.equals("tan")||s.equals("log")||s.equals("ln")||s.equals("√")||s.equals("x²")||s.equals("π")||s.equals("e")||s.equals("!")) return operatorColor;
        return key;
    }
    private int buttonText(String s) { if(s.equals("="))return Color.WHITE; if(s.equals("AC"))return light?Color.rgb(190,53,75):Color.rgb(255,155,173); if(buttonColor(s)==operatorColor)return accent; return text; }
    private void tap(String s) {
        if(s.equals("AC")){expression="";resultFresh=false;updateDisplay();return;}
        if(s.equals("DEL")||s.equals("⌫")){if(!expression.isEmpty())expression=expression.substring(0,expression.length()-1);resultFresh=false;updateDisplay();return;}
        if(s.equals("=")){evaluate();return;}
        if(s.equals("+/−")){if(expression.isEmpty())expression="-";else if(expression.startsWith("-"))expression=expression.substring(1);else expression="-"+expression;updateDisplay();return;}
        if(resultFresh && (isDigit(s)||s.equals("."))) expression="";
        resultFresh=false;
        switch(s){
            case "sin": case "cos": case "tan": case "log": case "ln": expression+=s+"("; break;
            case "√": expression+="sqrt("; break;
            case "x²": expression+="^2"; break;
            case "π": expression+="pi"; break;
            case "e": expression+="e"; break;
            case "00": expression+="00"; break;
            default: expression+=s;
        }
        updateDisplay();
    }
    private boolean isDigit(String s){return s.length()==1 && s.charAt(0)>='0'&&s.charAt(0)<='9';}
    private void updateDisplay(){ if(expressionView!=null){expressionView.setText(expression.isEmpty()?"Enter a calculation":expression); if(resultView!=null && !resultFresh)resultView.setText("0");} }
    private void evaluate(){
        if(expression.trim().isEmpty())return;
        try { double value = new Parser(expression,degrees).parse(); if(!Double.isFinite(value))throw new Exception("Math error"); String answer=format(value); history.add(0,expression+" = "+answer); if(history.size()>30)history.remove(history.size()-1); expression=answer; resultFresh=true; expressionView.setText("= "+answer); resultView.setText(answer); }
        catch(Exception e){Toast.makeText(this,"Check the expression",Toast.LENGTH_SHORT).show(); resultView.setText("Error");}
    }
    private String format(double v){ if(Math.abs(v)<1e-12)v=0; if(Math.abs(v)<1e12 && v==Math.rint(v))return String.format(Locale.US,"%.0f",v); return BigDecimal.valueOf(v).setScale(10,RoundingMode.HALF_UP).stripTrailingZeros().toPlainString(); }
    private void showHistory(){
        if(history.isEmpty()){new AlertDialog.Builder(this).setTitle("Calculation history").setMessage("Your recent calculations will appear here.").setPositiveButton("OK",null).show();return;}
        String[] items=history.toArray(new String[0]); new AlertDialog.Builder(this).setTitle("Calculation history").setItems(items,(d,which)->{String item=items[which];int ix=item.lastIndexOf(" = ");expression=ix>=0?item.substring(ix+3):item;resultFresh=true;updateDisplay();expressionView.setText(item);resultView.setText(expression);}).setNeutralButton("Clear history",(d,w)->history.clear()).setNegativeButton("Close",null).show();
    }
    private Button smallButton(String value,int color,int textColor){Button b=new Button(this);b.setText(value);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(textColor);b.setBackground(round(color,14));b.setPadding(dp(10),0,dp(10),0);b.setMinWidth(dp(44));b.setMinHeight(dp(42));b.setStateListAnimator(null);return b;}
    private TextView label(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));return t;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}

    private static class Parser {
        private final String s; private final boolean degrees; private int p=0;
        Parser(String s,boolean degrees){this.s=s.replace("×","*").replace("÷","/").replace("−","-").replace("%","%");this.degrees=degrees;}
        double parse() throws Exception {double v=expression();skip();if(p<s.length())throw new Exception("Unexpected token");return v;}
        double expression() throws Exception {double v=term();while(true){skip();if(eat('+'))v+=term();else if(eat('-'))v-=term();else return v;}}
        double term() throws Exception {double v=unary();while(true){skip();if(eat('*'))v*=unary();else if(eat('/')){double d=unary();if(d==0)throw new Exception("Divide by zero");v/=d;}else return v;}}
        double unary() throws Exception {skip();if(eat('+'))return unary();if(eat('-'))return -unary();double v=power();while(true){skip();if(eat('%'))v/=100.0;else if(eat('!')){if(v<0||v>170||v!=Math.rint(v))throw new Exception("Factorial domain");double f=1;for(int i=2;i<=(int)v;i++)f*=i;v=f;}else return v;}}
        double power() throws Exception {double v=primary();skip();if(eat('^'))v=Math.pow(v,unary());return v;}
        double primary() throws Exception {
            skip(); if(eat('(')){double v=expression();skip();if(!eat(')'))throw new Exception("Missing )");return v;}
            if(p>=s.length())throw new Exception("Expected value");
            if(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'){int st=p;while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++;return Double.parseDouble(s.substring(st,p));}
            if(Character.isLetter(s.charAt(p))){int st=p;while(p<s.length()&&Character.isLetter(s.charAt(p)))p++;String name=s.substring(st,p).toLowerCase(Locale.US);if(name.equals("pi"))return Math.PI;if(name.equals("e"))return Math.E;skip();if(!eat('('))throw new Exception("Expected (");double x=expression();skip();if(!eat(')'))throw new Exception("Missing )");switch(name){case "sin":return Math.sin(angle(x));case "cos":return Math.cos(angle(x));case "tan":return Math.tan(angle(x));case "log":if(x<=0)throw new Exception("Domain");return Math.log10(x);case "ln":if(x<=0)throw new Exception("Domain");return Math.log(x);case "sqrt":if(x<0)throw new Exception("Domain");return Math.sqrt(x);default:throw new Exception("Unknown function");}}
            throw new Exception("Unexpected character");
        }
        double angle(double x){return degrees?Math.toRadians(x):x;}
        void skip(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}
        boolean eat(char c){if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false;}
    }
}
